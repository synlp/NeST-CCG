This is the latest known (to me) version of the candc software package. It
includes, among other things, the C&C parser and Boxer 1. This is a working
copy of the now-defunct candc Subversion repository. It includes some changes
to Boxer that were never committed. Development of Boxer 1 has since ceased and
Boxer 2 is now being developed by Johan Bos. The source code of Boxer 2 has not
been released so far.

Boxer 1 is still used in the Groningen Meaning Bank (http://gmb.let.rug.nl)
while Boxer 2 is used in the Parallel Meaning Bank (http://pmb.let.rug.nl).

Kilian Evang, 2017-08-10
