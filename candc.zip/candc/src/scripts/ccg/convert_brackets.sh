#!/usr/bin/env sed -f

s/-LRB-/(/g;
s/-RRB-/)/g;
s/-LCB-/{/g;
s/-RCB-/}/g;
s/-LSB-/[/g;
s/-RSB-/]/g;
