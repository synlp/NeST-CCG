:- module(version,[version/1]).
version('boxer v1.00 (unix build on 14 February 2018, 12:40:58)').
