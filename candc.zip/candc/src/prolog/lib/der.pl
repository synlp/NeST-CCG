
:- module(der,[der/2]).

%:- use_module(boxer(slashes)).

:- ['working/doc/derivations.pl'].


