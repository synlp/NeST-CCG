
:- module(semlex,[lexcall/6]).

:- use_module(boxer(slashes)).

:- ['working/calls.lex'].


