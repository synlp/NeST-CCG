namespace NLP {
  const char *VERSION = "v1.00";

  const char *BUILD = "(unix build on 14 February 2018, 12:40:58)";
}
